npm i cookie-parser cors csurf express dotenv express-async-errors helmet jsonwebtoken  morgan per-env sqlite3 sequelize sequelize-cli;
npm i -D nodemon dotenv-cli;
npx sequelize db:migrate;
npm start;